package adapter;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import vn.edu.stu.doanquanlychitieu_nguyenhuutruong.R;

public class DanhMucChiTieuAdapter extends RecyclerView.Adapter<DanhMucChiTieuAdapter.ViewHolder> {

    private List<String> danhMucChiTieuList;
    private OnItemClickListener listener;

    // Interface để nghe sự kiện click
    public interface OnItemClickListener {
        void onEditClick(int position);
        void onDeleteClick(int position);
    }

    // Constructor
    public DanhMucChiTieuAdapter(List<String> danhMucChiTieuList, OnItemClickListener listener) {
        this.danhMucChiTieuList = danhMucChiTieuList != null ? danhMucChiTieuList : new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_danh_muc, parent, false); // Dùng chung layout item_danh_muc
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String danhMucChiTieu = danhMucChiTieuList.get(position);
        holder.textView.setText(danhMucChiTieu);

        // Lắng nghe sự kiện click
        holder.btnEdit.setOnClickListener(v -> listener.onEditClick(position));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(position));
    }

    @Override
    public int getItemCount() {
        return danhMucChiTieuList.size();
    }

    // ViewHolder giữ các view con
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        Button btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tvDanhMucName);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    // Phương thức để cập nhật dữ liệu trong adapter
    public void updateDanhMucChiTieuList(List<String> newDanhMucChiTieuList) {
        if (newDanhMucChiTieuList != null) {
            this.danhMucChiTieuList = newDanhMucChiTieuList;
            notifyDataSetChanged();  // Làm mới RecyclerView
        }
    }
}
