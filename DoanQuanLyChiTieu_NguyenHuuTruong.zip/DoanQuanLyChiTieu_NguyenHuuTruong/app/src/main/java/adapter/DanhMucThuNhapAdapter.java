package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import vn.edu.stu.doanquanlychitieu_nguyenhuutruong.R;

public class DanhMucThuNhapAdapter extends RecyclerView.Adapter<DanhMucThuNhapAdapter.ViewHolder> {

    private List<String> danhMucList;
    private OnItemClickListener listener;

    // Interface để nghe sự kiện click
    public interface OnItemClickListener {
        void onItemClick(String danhMuc);

        void onEditClick(int position);
        void onDeleteClick(int position);
    }

    // Constructor
    public DanhMucThuNhapAdapter(List<String> danhMucList, OnItemClickListener listener) {
        this.danhMucList = danhMucList != null ? danhMucList : new ArrayList<>();  // Đảm bảo danhMucList không null
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_danh_muc, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String danhMuc = danhMucList.get(position);
        holder.textView.setText(danhMuc);

        // Lắng nghe sự kiện click
        holder.btnEdit.setOnClickListener(v -> listener.onEditClick(position));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(position));
    }

    @Override
    public int getItemCount() {
        return danhMucList.size();
    }

    // ViewHolder giữ các view con
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        Button btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tvDanhMucName);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    // Phương thức để cập nhật dữ liệu trong adapter
    public void updateDanhMucList(List<String> newDanhMucList) {
        if (newDanhMucList != null) {
            this.danhMucList = newDanhMucList;
            notifyDataSetChanged();  // Làm mới RecyclerView
        }
    }
}
