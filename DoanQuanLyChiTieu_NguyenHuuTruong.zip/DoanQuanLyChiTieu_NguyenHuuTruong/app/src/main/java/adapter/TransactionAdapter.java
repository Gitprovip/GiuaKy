package adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

import vn.edu.stu.doanquanlychitieu_nguyenhuutruong.R;
import vn.edu.stu.doanquanlychitieu_nguyenhuutruong.Transaction;

public class TransactionAdapter extends ArrayAdapter<Transaction> {
    private Context context;
    private ArrayList<Transaction> transactions;

    public TransactionAdapter(Context context, ArrayList<Transaction> transactions) {
        super(context, 0, transactions);
        this.context = context;
        this.transactions = transactions;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_transaction, parent, false);
        }

        Transaction transaction = transactions.get(position);

        TextView tvAmount = convertView.findViewById(R.id.tvAmount);
        TextView tvDate = convertView.findViewById(R.id.tvDate);
        TextView tvDescription = convertView.findViewById(R.id.tvDescription);
        TextView tvCategory = convertView.findViewById(R.id.tvCategory);

        // Set dữ liệu cho các TextView
        tvAmount.setText(String.format(Locale.getDefault(), "%.0fđ", transaction.getAmount()));
        tvDate.setText(transaction.getDate());
        tvDescription.setText(transaction.getDescription());
        tvCategory.setText(transaction.getCategoryName());

        return convertView;
    }
}
