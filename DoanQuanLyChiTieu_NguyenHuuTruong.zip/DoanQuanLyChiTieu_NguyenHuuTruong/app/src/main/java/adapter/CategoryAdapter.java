package adapter;

import android.content.Context;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

import vn.edu.stu.doanquanlychitieu_nguyenhuutruong.Category;

public class CategoryAdapter extends ArrayAdapter<Category> {
    public CategoryAdapter(Context context, ArrayList<Category> categories) {
        super(context, android.R.layout.simple_dropdown_item_1line, categories);
    }
}
