package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class HomeActivity extends AppCompatActivity {

    // Declare the views
    private Button buttonLogout, buttonExpense, btnTN, buttonDanhMucCT, buttonDanhMucTN;
    private Button buttonReport, buttonBudget;
    private TextView title, greeting, soDuHienTai, balanceValue, expenseValue;
    private TextView tvTongChiTieuHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // Ensure correct layout file

        // Initialize the views
        buttonLogout = findViewById(R.id.button_logout);
        buttonExpense = findViewById(R.id.button_expense);
        btnTN = findViewById(R.id.btnTN);
        buttonDanhMucCT = findViewById(R.id.button_DanhMucCT);
        buttonDanhMucTN = findViewById(R.id.button_DanhMucTN);
        buttonReport = findViewById(R.id.button_report);
        buttonBudget = findViewById(R.id.button_budget);
        greeting = findViewById(R.id.greeting);
        title = findViewById(R.id.title);
        soDuHienTai = findViewById(R.id.soDuHienTai);
        balanceValue = findViewById(R.id.balance_value);
        expenseValue = findViewById(R.id.expense_value);
        tvTongChiTieuHome = findViewById(R.id.tvTongChiTieuHome);

        // Get the username from the UserSession (if available)
        String username = UserSession.getInstance().getUsername();
        if (username != null) {
            greeting.setText("Xin chào: " + username);
        } else {
            greeting.setText("Xin chào!");
        }

        // Retrieve data from SharedPreferences (if any)
        SharedPreferences sharedPreferences = getSharedPreferences("UserData", MODE_PRIVATE);
        float totalIncome = sharedPreferences.getFloat("totalIncome", 0f);  // Default value is 0f
        float totalExpense = sharedPreferences.getFloat("totalExpense", 0f); // Default value is 0f
        float tongChiTieu = totalExpense; // Total spending is totalExpense

        // Update the UI with the total income, expense, and total spending
        balanceValue.setText(String.format("%,d đ", (int) totalIncome));
        expenseValue.setText(String.format("%,d đ", (int) totalExpense));
        tvTongChiTieuHome.setText(String.format(Locale.getDefault(), "Tổng chi tiêu: %,d đ", (int) tongChiTieu));

        // Calculate and update the current balance (totalIncome - totalExpense)
        float currentBalance = totalIncome - totalExpense;
        soDuHienTai.setText(String.format("%,d đ", (int) currentBalance));

        // Set the logout functionality
        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Log out and go back to the login screen
                UserSession.getInstance().logout(); // Clear login data
                Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });

        // Set event for the expense button
        buttonExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to expense management screen
                Intent intent = new Intent(HomeActivity.this, ChiTieuActivity.class);
                startActivity(intent);
            }
        });

        // Set event for the income button
        btnTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to income management screen
                Intent intent = new Intent(HomeActivity.this, ThuNhapActivity.class);
                startActivity(intent);
            }
        });

        // Set event for the expense category button
        buttonDanhMucCT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to expense category management screen
                Intent intent = new Intent(HomeActivity.this, DanhMucChiTieu.class);
                startActivity(intent);
            }
        });

        // Set event for the income category button
        buttonDanhMucTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to income category management screen
                Intent intent = new Intent(HomeActivity.this, DanhMucThuNhap.class);
                startActivity(intent);
            }
        });

        // Set event for the report button to navigate to ReportActivity
        buttonReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the report and analysis screen
                Intent intent = new Intent(HomeActivity.this, ReportActivity.class);
                startActivity(intent);
            }
        });

        // Set event for the budget button to navigate to BudgetActivity
        buttonBudget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the budget setup screen
                Intent intent = new Intent(HomeActivity.this, BudgetActivity.class);
                startActivity(intent);
            }
        });

        // Retrieve data from the Intent (if any)
        Intent intent = getIntent();
        totalIncome = (float) intent.getDoubleExtra("totalIncome", totalIncome); // Total income
        totalExpense = (float) intent.getDoubleExtra("totalExpense", totalExpense); // Total expense

        // Update the SharedPreferences with the new values
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("totalIncome", totalIncome);
        editor.putFloat("totalExpense", totalExpense);
        editor.apply(); // Save the data
    }
}
