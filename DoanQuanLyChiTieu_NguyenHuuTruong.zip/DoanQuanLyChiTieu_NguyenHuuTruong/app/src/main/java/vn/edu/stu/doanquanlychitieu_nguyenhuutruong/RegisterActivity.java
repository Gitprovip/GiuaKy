package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class RegisterActivity extends AppCompatActivity {

    private EditText edtUsername, edtEmail, edtPassword, edtConfirmPassword;
    private Button btnRegister;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register); // Giao diện XML của RegisterActivity

        // Khởi tạo các view
        edtUsername = findViewById(R.id.edtUsername);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        edtConfirmPassword = findViewById(R.id.edtConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);

        dbHelper = new DatabaseHelper(this);

        // Xử lý sự kiện khi người dùng nhấn nút đăng ký
        btnRegister.setOnClickListener(v -> {
            String username = edtUsername.getText().toString().trim();
            String email = edtEmail.getText().toString().trim();
            String password = edtPassword.getText().toString().trim();
            String confirmPassword = edtConfirmPassword.getText().toString().trim();

            // Kiểm tra các trường nhập liệu
            if (TextUtils.isEmpty(username)) {
                edtUsername.setError("Vui lòng nhập tên người dùng.");
                return;
            }
            if (TextUtils.isEmpty(email)) {
                edtEmail.setError("Vui lòng nhập email.");
                return;
            }
            if (TextUtils.isEmpty(password)) {
                edtPassword.setError("Vui lòng nhập mật khẩu.");
                return;
            }
            if (TextUtils.isEmpty(confirmPassword)) {
                edtConfirmPassword.setError("Vui lòng xác nhận mật khẩu.");
                return;
            }
            if (!password.equals(confirmPassword)) {
                edtConfirmPassword.setError("Mật khẩu xác nhận không khớp.");
                return;
            }

            // Kiểm tra xem email và tên người dùng đã tồn tại chưa
            if (dbHelper.isEmailExist(email)) {
                Toast.makeText(RegisterActivity.this, "Email đã tồn tại.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (dbHelper.isUsernameExist(username)) {
                Toast.makeText(RegisterActivity.this, "Tên người dùng đã tồn tại.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Tiến hành thêm người dùng vào cơ sở dữ liệu
            boolean isSuccess = dbHelper.themUser(username, email, password);

            if (isSuccess) {
                Toast.makeText(RegisterActivity.this, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();
                // Chuyển về màn hình đăng nhập
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(RegisterActivity.this, "Đăng ký thất bại. Vui lòng thử lại.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
