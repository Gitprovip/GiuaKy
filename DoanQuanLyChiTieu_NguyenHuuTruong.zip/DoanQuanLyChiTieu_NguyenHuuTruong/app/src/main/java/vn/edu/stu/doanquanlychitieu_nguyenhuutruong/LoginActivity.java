package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvRegisterLink;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Ánh xạ view từ XML
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegisterLink = findViewById(R.id.tvRegisterLink);

        dbHelper = new DatabaseHelper(this);

        // Xử lý sự kiện nhấn nút đăng nhập
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                } else {
                    if (kiemTraDangNhap(username, password)) {
                        dbHelper.capNhatThoiGianDangNhap(username);  // Cập nhật thời gian đăng nhập

                        // Lấy userId từ cơ sở dữ liệu (giả sử bạn có phương thức getUserIdByUsername)
                        int userId = dbHelper.getUserIdByUsername(username);

                        // Cập nhật thông tin người dùng trong session (bao gồm userId)
                        UserSession.getInstance().setUsername(username, userId);

                        Toast.makeText(LoginActivity.this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, "Tên đăng nhập hoặc mật khẩu không đúng!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        // Xử lý sự kiện khi người dùng nhấn vào liên kết đăng ký
        tvRegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mở RegisterActivity để đăng ký
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    // Phương thức kiểm tra thông tin đăng nhập
    private boolean kiemTraDangNhap(String username, String password) {
        // Lấy mật khẩu đã mã hóa từ cơ sở dữ liệu
        String storedPasswordHash = dbHelper.getUserPasswordHash(username);
        if (storedPasswordHash != null) {
            String inputPasswordHash = dbHelper.hashPassword(password); // Mã hóa mật khẩu người dùng nhập
            return storedPasswordHash.equals(inputPasswordHash); // So sánh mật khẩu mã hóa
        }
        return false;
    }



}
