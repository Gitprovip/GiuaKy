package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

public class UserSession {
    private static UserSession instance;
    private String username;
    private boolean isLoggedIn;
    private int userId; // Thêm thuộc tính userId
    private double totalIncome; // Tổng thu nhập
    private double totalExpense; // Tổng chi tiêu

    private UserSession() {
        isLoggedIn = false;
    }

    // Đảm bảo chỉ có một instance của UserSession
    public static synchronized UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    // Lấy tên người dùng
    public String getUsername() {
        return username;
    }

    // Cập nhật thông tin người dùng (tên và ID)
    public void setUsername(String username, int userId) {
        this.username = username;
        this.userId = userId;
        this.isLoggedIn = true;
    }

    // Lấy ID người dùng
    public int getUserId() {
        return userId;
    }

    // Kiểm tra trạng thái đăng nhập
    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    // Đăng xuất người dùng
    public void logout() {
        this.username = null;
        this.userId = 0; // Đặt userId về 0 khi người dùng đăng xuất
        this.isLoggedIn = false;
    }

    // Xóa tất cả thông tin phiên làm việc
    public void clear() {
        this.username = null;
        this.userId = 0; // Xóa userId
        this.isLoggedIn = false;
    }

    // Lưu tổng thu nhập vào phiên làm việc
    public void setTotalIncome(double totalIncome) {
        this.totalIncome = totalIncome;
    }

    // Lưu tổng chi tiêu vào phiên làm việc
    public void setTotalExpense(double totalExpense) {
        this.totalExpense = totalExpense;
    }

    // Lấy tổng thu nhập
    public double getTotalIncome() {
        return totalIncome;
    }

    // Lấy tổng chi tiêu
    public double getTotalExpense() {
        return totalExpense;
    }
}
