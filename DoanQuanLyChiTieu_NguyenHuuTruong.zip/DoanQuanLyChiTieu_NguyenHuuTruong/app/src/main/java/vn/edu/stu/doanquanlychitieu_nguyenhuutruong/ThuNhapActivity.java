package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import adapter.TransactionAdapter;

public class ThuNhapActivity extends AppCompatActivity {

    private EditText edtSoTien, edtMota;
    private Button btnChonDanhMuc, btnLuuThuNhap;
    private ImageView btnChonNgay, btnChonGio;
    private TextView tvDateTime, tvTongThuNhap;
    private DatabaseHelper dbHelper;

    private ImageButton btnGoToHome;  // Chỉnh sửa để sử dụng ImageButton
    private int selectedCategoryId;
    private int currentUserId = 1; // ID người dùng hiện tại
    private ListView lvThuNhap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thu_nhap);

        dbHelper = new DatabaseHelper(this);

        // Khởi tạo các View
        edtSoTien = findViewById(R.id.edtSoTien);
        edtMota = findViewById(R.id.edtMota);
        btnChonDanhMuc = findViewById(R.id.btnChonDanhMuc);
        btnChonNgay = findViewById(R.id.btnChonNgay);
        btnChonGio = findViewById(R.id.btnChonGio);
        tvDateTime = findViewById(R.id.tvDateTime);
        tvTongThuNhap = findViewById(R.id.tvTongThuNhap);
        btnLuuThuNhap = findViewById(R.id.btnLuuThuNhap);
        lvThuNhap = findViewById(R.id.lvThuNhap);
        btnGoToHome = findViewById(R.id.btnGoToHome);

        // Hiển thị danh sách thu nhập và tính tổng thu nhập
        hienThiThuNhap();

        // Sự kiện chọn danh mục
        btnChonDanhMuc.setOnClickListener(v -> showCategoryDialog());

        // Sự kiện chọn ngày
        btnChonNgay.setOnClickListener(v -> showDatePickerDialog());

        // Sự kiện chọn giờ
        btnChonGio.setOnClickListener(v -> showTimePickerDialog());

        // Sự kiện lưu thu nhập
        btnLuuThuNhap.setOnClickListener(v -> themThuNhap());

        // Sự kiện chuyển sang HomeActivity và truyền tổng thu nhập
        btnGoToHome.setOnClickListener(v -> {
            // Tính tổng thu nhập
            ArrayList<Transaction> transactions = dbHelper.layTatCaGiaoDich(currentUserId, "thu nhập");
            double totalIncome = 0;
            for (Transaction transaction : transactions) {
                totalIncome += transaction.getAmount();
            }
            // Chuyển sang HomeActivity và truyền tổng thu nhập qua Intent
            Intent intent = new Intent(ThuNhapActivity.this, HomeActivity.class);
            intent.putExtra("totalIncome", totalIncome); // Truyền tổng thu nhập
            startActivity(intent); // Mở HomeActivity
            finish(); // Đóng ThuNhapActivity
        });
    }

    // Hàm hiển thị danh mục thu nhập
    private void showCategoryDialog() {
        ArrayList<String> danhMucThuNhap = (ArrayList<String>) dbHelper.layDanhMucTheoLoai("thu nhập");

        if (danhMucThuNhap.isEmpty()) {
            Toast.makeText(this, "Không có danh mục thu nhập", Toast.LENGTH_SHORT).show();
            return;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, danhMucThuNhap);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Chọn danh mục thu nhập");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_listview_category, null);
        ListView listViewCategories = dialogView.findViewById(R.id.listViewCategories);
        listViewCategories.setAdapter(adapter);

        listViewCategories.setOnItemClickListener((parent, view, position, id) -> {
            String selectedCategory = danhMucThuNhap.get(position);
            selectedCategoryId = dbHelper.layCategoryIdTheoTen(selectedCategory, "thu nhập");
            btnChonDanhMuc.setText(selectedCategory);
            builder.create().dismiss();
        });

        builder.setView(dialogView);
        builder.setCancelable(true);
        builder.create().show();
    }

    // Hàm hiển thị thu nhập và tính tổng thu nhập
    private void hienThiThuNhap() {
        ArrayList<Transaction> transactions = dbHelper.layTatCaGiaoDich(currentUserId, "thu nhập");

        if (transactions == null || transactions.isEmpty()) {
            Toast.makeText(this, "Không có thu nhập", Toast.LENGTH_SHORT).show();
            return;
        }

        double totalIncome = 0;
        for (Transaction transaction : transactions) {
            totalIncome += transaction.getAmount();
        }

        tvTongThuNhap.setText("Tổng thu nhập: " + String.format(Locale.getDefault(), "%,d đ", (int) totalIncome));

        TransactionAdapter adapter = new TransactionAdapter(this, transactions);
        lvThuNhap.setAdapter(adapter);
    }

    // Hàm thêm thu nhập vào cơ sở dữ liệu
    private void themThuNhap() {
        try {
            // Lấy số tiền và mô tả thu nhập
            double soTien = Double.parseDouble(edtSoTien.getText().toString().replace(".", ""));
            String ngayThang = tvDateTime.getText().toString();
            String moTa = edtMota.getText().toString();

            // Kiểm tra xem người dùng đã chọn ngày và giờ chưa
            if (ngayThang.equals("Ngày và giờ sẽ được hiển thị ở đây")) {
                Toast.makeText(this, "Vui lòng chọn ngày và giờ", Toast.LENGTH_SHORT).show();
                return;
            }

            // Lưu thu nhập vào cơ sở dữ liệu
            boolean isSuccess = dbHelper.themThuNhap(soTien, ngayThang, moTa, selectedCategoryId, currentUserId);

            if (isSuccess) {
                Toast.makeText(this, "Thêm thu nhập thành công", Toast.LENGTH_SHORT).show();
                edtSoTien.setText("");  // Xóa các trường nhập
                edtMota.setText("");
                tvDateTime.setText("Ngày và giờ sẽ được hiển thị ở đây");
                btnChonDanhMuc.setText("Chọn nguồn thu");
                hienThiThuNhap();  // Cập nhật lại danh sách thu nhập
            } else {
                Toast.makeText(this, "Thêm thu nhập thất bại", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Vui lòng nhập số tiền hợp lệ", Toast.LENGTH_SHORT).show();
        }
    }

    // Hàm chọn ngày từ DatePicker
    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                ThuNhapActivity.this,
                (view, selectedYear, selectedMonth, selectedDayOfMonth) -> {
                    String selectedDate = selectedDayOfMonth + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    tvDateTime.setText(selectedDate + " " + tvDateTime.getText().toString().split(" ")[1]);
                },
                year, month, dayOfMonth
        );
        datePickerDialog.show();
    }

    // Hàm chọn giờ từ TimePicker
    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                ThuNhapActivity.this,
                (view, selectedHour, selectedMinute) -> {
                    String selectedTime = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
                    tvDateTime.setText(tvDateTime.getText().toString().split(" ")[0] + " " + selectedTime);
                },
                hour, minute, true
        );
        timePickerDialog.show();
    }
}
