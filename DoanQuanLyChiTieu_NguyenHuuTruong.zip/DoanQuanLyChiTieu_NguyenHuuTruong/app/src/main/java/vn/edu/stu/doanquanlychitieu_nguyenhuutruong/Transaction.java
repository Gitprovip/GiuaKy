package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

public class Transaction {
    private int id;
    private double amount;
    private String date;
    private String description;
    private String categoryName;

    // Constructor
    public Transaction(int id, double amount, String date, String description, String categoryName) {
        this.id = id;
        this.amount = amount;
        this.date = date;
        this.description = description;
        this.categoryName = categoryName;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public double getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public String getCategoryName() {
        return categoryName;
    }

    // Setter methods (nếu cần thay đổi giá trị của thuộc tính sau khi khởi tạo)
    public void setId(int id) {
        this.id = id;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
