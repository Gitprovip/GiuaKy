package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "QuanLyChiTieu.db";
    private static final int DATABASE_VERSION = 2;
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private static final String TABLE_USERS = "Users";
    private static final String TABLE_CATEGORIES = "Categories";
    private static final String TABLE_TRANSACTIONS = "Transactions";
    private static final String TABLE_BUDGETS = "Budgets";
    private static final String TABLE_NOTIFICATIONS = "Notifications";


    // Các cột cho bảng Users
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD_HASH = "password_hash";
    private static final String COLUMN_CREATED_AT = "created_at";
    private static final String COLUMN_LAST_LOGIN = "last_login";

    // Các cột cho bảng Categories
    public static final String COLUMN_CATEGORY_ID = "category_id";
    public static final String COLUMN_CATEGORY_NAME = "name";
    public static final String COLUMN_CATEGORY_TYPE = "type";
    private static final String COLUMN_CATEGORY_USER_ID = "user_id";

    // Các cột cho bảng Transactions
    private static final String COLUMN_TRANSACTION_ID = "transaction_id";
    private static final String COLUMN_AMOUNT = "amount";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_TRANSACTION_CATEGORY_ID = "category_id";
    private static final String COLUMN_TRANSACTION_USER_ID = "user_id";
    private static final String COLUMN_TRANSACTION_TYPE = "type";

    // Các cột cho bảng Budgets
    private static final String COLUMN_BUDGET_ID = "budget_id";
    private static final String COLUMN_BUDGET_CATEGORY_ID = "category_id";
    private static final String COLUMN_BUDGET_AMOUNT = "amount";
    private static final String COLUMN_START_DATE = "start_date";
    private static final String COLUMN_END_DATE = "end_date";
    private static final String COLUMN_BUDGET_USER_ID = "user_id";

    // Các cột cho bảng Notifications
    private static final String COLUMN_NOTIFICATION_ID = "notification_id";
    private static final String COLUMN_NOTIFICATION_USER_ID = "user_id";
    private static final String COLUMN_MESSAGE = "message";
    private static final String COLUMN_NOTIFICATION_DATE = "date";
    private static final String COLUMN_STATUS = "status";

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tạo bảng Users
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT, "
                + COLUMN_EMAIL + " TEXT UNIQUE, "
                + COLUMN_PASSWORD_HASH + " TEXT, "
                + COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP, "
                + COLUMN_LAST_LOGIN + " DATETIME"
                + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Tạo bảng Categories
        String CREATE_CATEGORIES_TABLE = "CREATE TABLE " + TABLE_CATEGORIES + "("
                + COLUMN_CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_CATEGORY_NAME + " TEXT, "
                + COLUMN_CATEGORY_TYPE + " TEXT, "
                + COLUMN_CATEGORY_USER_ID + " INTEGER, "
                + "FOREIGN KEY(" + COLUMN_CATEGORY_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")"
                + ")";
        db.execSQL(CREATE_CATEGORIES_TABLE);

        // Tạo bảng Transactions
        String CREATE_TRANSACTIONS_TABLE = "CREATE TABLE " + TABLE_TRANSACTIONS + "("
                + COLUMN_TRANSACTION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_AMOUNT + " REAL, "
                + COLUMN_DATE + " DATETIME DEFAULT CURRENT_TIMESTAMP, "
                + COLUMN_DESCRIPTION + " TEXT, "
                + COLUMN_TRANSACTION_CATEGORY_ID + " INTEGER, "
                + COLUMN_TRANSACTION_USER_ID + " INTEGER, "
                + COLUMN_TRANSACTION_TYPE + " TEXT, "
                + "FOREIGN KEY(" + COLUMN_TRANSACTION_CATEGORY_ID + ") REFERENCES " + TABLE_CATEGORIES + "(" + COLUMN_CATEGORY_ID + "), "
                + "FOREIGN KEY(" + COLUMN_TRANSACTION_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")"
                + ")";
        db.execSQL(CREATE_TRANSACTIONS_TABLE);

        // Tạo bảng Budgets
        String CREATE_BUDGETS_TABLE = "CREATE TABLE " + TABLE_BUDGETS + "("
                + COLUMN_BUDGET_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_BUDGET_CATEGORY_ID + " INTEGER, "
                + COLUMN_BUDGET_AMOUNT + " REAL, "
                + COLUMN_START_DATE + " DATETIME, "
                + COLUMN_END_DATE + " DATETIME, "
                + COLUMN_BUDGET_USER_ID + " INTEGER, "
                + "FOREIGN KEY(" + COLUMN_BUDGET_CATEGORY_ID + ") REFERENCES " + TABLE_CATEGORIES + "(" + COLUMN_CATEGORY_ID + "), "
                + "FOREIGN KEY(" + COLUMN_BUDGET_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")"
                + ")";
        db.execSQL(CREATE_BUDGETS_TABLE);

        // Tạo bảng Notifications
        String CREATE_NOTIFICATIONS_TABLE = "CREATE TABLE " + TABLE_NOTIFICATIONS + "("
                + COLUMN_NOTIFICATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NOTIFICATION_USER_ID + " INTEGER, "
                + COLUMN_MESSAGE + " TEXT, "
                + COLUMN_NOTIFICATION_DATE + " DATETIME DEFAULT CURRENT_TIMESTAMP, "
                + COLUMN_STATUS + " TEXT, "
                + "FOREIGN KEY(" + COLUMN_NOTIFICATION_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")"
                + ")";
        db.execSQL(CREATE_NOTIFICATIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BUDGETS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTIFICATIONS);
        onCreate(db);
    }
//USER
// Phương thức đăng ký người dùng
public boolean themUser(String username, String email, String password) {
    // Mã hóa mật khẩu trước khi lưu
    String passwordHash = hashPassword(password);

    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues values = new ContentValues();
    values.put(COLUMN_USERNAME, username);
    values.put(COLUMN_EMAIL, email);
    values.put(COLUMN_PASSWORD_HASH, passwordHash);
    values.put(COLUMN_CREATED_AT, getCurrentDate());
    values.put(COLUMN_LAST_LOGIN, (String) null);


    long result = db.insert(TABLE_USERS, null, values);
    db.close();

    return result != -1;
}

    // Phương thức mã hóa mật khẩu (sử dụng SHA-256 hoặc một phương pháp bảo mật khác)
    public String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Lấy ngày hiện tại để lưu vào trường created_at
    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }
    // Kiểm tra nếu email đã tồn tại
    public boolean isEmailExist(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_EMAIL + " = ?", new String[]{email});

        if (cursor.moveToFirst()) {
            cursor.close();
            return true; // Email đã tồn tại
        } else {
            cursor.close();
            return false; // Email chưa tồn tại
        }
    }

    // Kiểm tra nếu username đã tồn tại
    public boolean isUsernameExist(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});

        if (cursor.moveToFirst()) {
            cursor.close();
            return true; // Username đã tồn tại
        } else {
            cursor.close();
            return false; // Username chưa tồn tại
        }
    }
    // Cập nhật thời gian đăng nhập cuối cùng
    public boolean capNhatThoiGianDangNhap(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_LAST_LOGIN, getCurrentDate());  // Cập nhật thời gian đăng nhập

        int rowsAffected = db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", new String[]{username});
        return rowsAffected > 0;
    }
    //login
    public String getUserPasswordHash(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_PASSWORD_HASH + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});

        if (cursor.moveToFirst()) {
            String passwordHash = cursor.getString(0);
            cursor.close();
            return passwordHash;
        }
        cursor.close();
        return null;
    }
    // Kiểm tra xem người dùng đã đăng nhập chưa
    public int getUserIdByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Truy vấn để lấy user_id dựa trên username
        String query = "SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        int userId = -1; // Giá trị mặc định nếu không tìm thấy
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                // Kiểm tra xem cột COLUMN_USER_ID có tồn tại hay không
                int columnIndex = cursor.getColumnIndex(COLUMN_USER_ID);
                if (columnIndex != -1) {
                    userId = cursor.getInt(columnIndex);  // Lấy user_id
                }
            }
            cursor.close();  // Đóng cursor khi không còn cần thiết
        }
        return userId;  // Trả về user_id hoặc -1 nếu không tìm thấy
    }



    public List<String> getDanhMucThuNhapByType(String type) {
        List<String> categories = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();  // Đọc cơ sở dữ liệu

        // Điều kiện lọc theo loại
        String selection = COLUMN_CATEGORY_TYPE + " = ?";
        String[] selectionArgs = {type};

        // Truy vấn cơ sở dữ liệu để lấy tất cả danh mục với loại "thu nhập"
        Cursor cursor = db.query(TABLE_CATEGORIES, new String[]{COLUMN_CATEGORY_NAME},
                selection, selectionArgs, null, null, null);

        // Kiểm tra kết quả truy vấn
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int columnIndex = cursor.getColumnIndex(COLUMN_CATEGORY_NAME);
                    if (columnIndex != -1) {
                        categories.add(cursor.getString(columnIndex));  // Thêm tên danh mục vào danh sách
                    } else {
                        Log.e("Lỗi", "Cột không tồn tại: " + COLUMN_CATEGORY_NAME);
                    }
                } while (cursor.moveToNext());  // Di chuyển đến bản ghi tiếp theo
            }
            cursor.close();  // Đóng cursor
        }
        return categories;  // Trả về danh sách các danh mục thu nhập
    }




    // Xóa danh mục thu nhập
    public void xoaDanhMucThuNhap(String categoryName) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CATEGORIES, COLUMN_CATEGORY_NAME + " = ?", new String[]{categoryName});
    }
    // Phương thức thêm danh mục thu nhập vào bảng Categories
    public void themDanhMucThuNhap(String name, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Insert vào bảng danh mục thu nhập
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, name);
        values.put(COLUMN_CATEGORY_TYPE, "thu nhập");  // Loại thu nhập
        values.put(COLUMN_CATEGORY_USER_ID, userId);  // Gán user_id

        db.insert(TABLE_CATEGORIES, null, values);
        db.close();
    }

    // Thêm phương thức sửa danh mục thu nhập trong DatabaseHelper
    public void capNhatDanhMucThuNhap(String oldCategory, String newCategory) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, newCategory);  // Cập nhật tên danh mục

        // Cập nhật danh mục thu nhập trong cơ sở dữ liệu
        db.update(TABLE_CATEGORIES, values, COLUMN_CATEGORY_NAME + " = ?", new String[]{oldCategory});
        db.close();
    }
    //CHI TIÊU
// Lấy tất cả danh mục chi tiêu của người dùng
    public List<String> getDanhMucChiTieuByType(String type) {
        List<String> categories = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();  // Đọc cơ sở dữ liệu

        // Điều kiện lọc theo loại
        String selection = COLUMN_CATEGORY_TYPE + " = ?";
        String[] selectionArgs = {type};

        // Truy vấn cơ sở dữ liệu để lấy tất cả danh mục với loại "chi tiêu"
        Cursor cursor = db.query(TABLE_CATEGORIES, new String[]{COLUMN_CATEGORY_NAME},
                selection, selectionArgs, null, null, null);

        // Kiểm tra kết quả truy vấn
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int columnIndex = cursor.getColumnIndex(COLUMN_CATEGORY_NAME);
                    if (columnIndex != -1) {
                        categories.add(cursor.getString(columnIndex));  // Thêm tên danh mục vào danh sách
                    } else {
                        Log.e("Lỗi", "Cột không tồn tại: " + COLUMN_CATEGORY_NAME);
                    }
                } while (cursor.moveToNext());  // Di chuyển đến bản ghi tiếp theo
            }
            cursor.close();  // Đóng cursor
        }
        return categories;  // Trả về danh sách các danh mục chi tiêu
    }
    // Xóa danh mục chi tiêu
    public void xoaDanhMucChiTieu(String categoryName) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CATEGORIES, COLUMN_CATEGORY_NAME + " = ?", new String[]{categoryName});
    }
    // Thêm danh mục chi tiêu vào bảng Categories
    public void themDanhMucChiTieu(String name, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Insert vào bảng danh mục chi tiêu
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, name);
        values.put(COLUMN_CATEGORY_TYPE, "chi tiêu");  // Loại chi tiêu
        values.put(COLUMN_CATEGORY_USER_ID, userId);  // Gán user_id

        db.insert(TABLE_CATEGORIES, null, values);
        db.close();
    }
    // Cập nhật danh mục chi tiêu trong DatabaseHelper
    public void capNhatDanhMucChiTieu(String oldCategory, String newCategory) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, newCategory);  // Cập nhật tên danh mục

        // Cập nhật danh mục chi tiêu trong cơ sở dữ liệu
        db.update(TABLE_CATEGORIES, values, COLUMN_CATEGORY_NAME + " = ?", new String[]{oldCategory});
        db.close();
    }

    // Phương thức lấy danh sách tên các danh mục theo loại (thu nhập hoặc chi tiêu)
    public List<String> layDanhMucTheoLoai(String type) {
        List<String> categoryNames = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_CATEGORY_TYPE + " = ?";
        String[] selectionArgs = {type}; // Ví dụ: "thu nhap" hoặc "chi tieu"

        Cursor cursor = db.query(TABLE_CATEGORIES, new String[]{COLUMN_CATEGORY_NAME},
                selection, selectionArgs, null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int columnIndex = cursor.getColumnIndex(COLUMN_CATEGORY_NAME);
                    if (columnIndex != -1) {
                        categoryNames.add(cursor.getString(columnIndex));
                    } else {
                        Log.e("Lỗi", "Cột không tồn tại: " + COLUMN_CATEGORY_NAME);
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        return categoryNames;
    }

    // Phương thức lấy ID danh mục theo tên và loại (thu nhập hoặc chi tiêu)
    public int layCategoryIdTheoTen(String categoryName, String type) {
        int categoryId = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_CATEGORY_ID + " FROM " + TABLE_CATEGORIES + " WHERE " + COLUMN_CATEGORY_NAME + " = ? AND " + COLUMN_CATEGORY_TYPE + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{categoryName, type});

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex(COLUMN_CATEGORY_ID);
                if (columnIndex != -1) {
                    categoryId = cursor.getInt(columnIndex);
                }
            }
            cursor.close();
        }
        db.close();
        return categoryId;
    }

    // Phương thức thêm thu nhập mới vào cơ sở dữ liệu
    public boolean themThuNhap(double soTien, String ngayThang, String moTa, int categoryId, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_AMOUNT, soTien);
        values.put(COLUMN_DATE, ngayThang);  // Định dạng "yyyy-MM-dd HH:mm:ss" hoặc bất kỳ định dạng nào phù hợp
        values.put(COLUMN_DESCRIPTION, moTa);
        values.put(COLUMN_TRANSACTION_CATEGORY_ID, categoryId);
        values.put(COLUMN_TRANSACTION_USER_ID, userId);
        values.put(COLUMN_TRANSACTION_TYPE, "thu nhập");  // Thêm giá trị cho cột type

        long result = db.insert(TABLE_TRANSACTIONS, null, values);
        db.close();

        return result != -1;  // Trả về true nếu thêm thành công, false nếu thất bại
    }

    // Phương thức xóa thu nhập theo ID giao dịch
    public boolean xoaThuNhap(int transactionId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Điều kiện để xóa giao dịch theo ID
        String selection = COLUMN_TRANSACTION_ID + " = ?";
        String[] selectionArgs = { String.valueOf(transactionId) };

        // Xóa giao dịch khỏi bảng
        int rowsAffected = db.delete(TABLE_TRANSACTIONS, selection, selectionArgs);
        db.close();

        return rowsAffected > 0;  // Trả về true nếu xóa thành công, false nếu thất bại
    }


    // Phương thức thêm chi tiêu mới vào cơ sở dữ liệu
    public boolean themChiTieu(double soTien, String ngayThang, String moTa, int categoryId, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_AMOUNT, soTien);
        values.put(COLUMN_DATE, ngayThang);  // Định dạng "yyyy-MM-dd HH:mm:ss" hoặc bất kỳ định dạng nào phù hợp
        values.put(COLUMN_DESCRIPTION, moTa);
        values.put(COLUMN_TRANSACTION_CATEGORY_ID, categoryId);
        values.put(COLUMN_TRANSACTION_USER_ID, userId);
        values.put(COLUMN_TRANSACTION_TYPE, "chi tiêu");  // Thêm giá trị cho cột type

        long result = db.insert(TABLE_TRANSACTIONS, null, values);
        db.close();

        return result != -1;  // Trả về true nếu thêm thành công, false nếu thất bại
    }


    // Phương thức lấy tất cả các giao dịch của người dùng, có thể lọc theo loại (thu nhập hoặc chi tiêu)
    public ArrayList<Transaction> layTatCaGiaoDich(int userId, String type) {
        ArrayList<Transaction> transactions = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT t.*, c." + COLUMN_CATEGORY_NAME + " FROM " + TABLE_TRANSACTIONS + " t " +
                "JOIN " + TABLE_CATEGORIES + " c ON t." + COLUMN_TRANSACTION_CATEGORY_ID + " = c." + COLUMN_CATEGORY_ID +
                " WHERE t." + COLUMN_TRANSACTION_USER_ID + " = ? AND c." + COLUMN_CATEGORY_TYPE + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId), type});

        if (cursor != null && cursor.moveToFirst()) {
            do {
                try {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TRANSACTION_ID));
                    double amount = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_AMOUNT));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE));
                    String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION));
                    String categoryName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY_NAME));

                    // Tạo đối tượng Transaction và thêm vào danh sách
                    Transaction transaction = new Transaction(id, amount, date, description, categoryName);
                    transactions.add(transaction);
                } catch (IllegalArgumentException e) {
                    Log.e("Database Error", "Column not found: " + e.getMessage());
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return transactions;
    }

    public boolean xoaChiTieu(int transactionId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete("transactions", "id = ?", new String[]{String.valueOf(transactionId)});
        db.close();
        return rowsDeleted > 0;
    }





}
