package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import adapter.DanhMucChiTieuAdapter;

public class DanhMucChiTieu extends AppCompatActivity {

    private RecyclerView recyclerViewDanhMucCT;
    private DanhMucChiTieuAdapter adapter;
    private List<String> danhMucChiTieuList = new ArrayList<>();
    private DatabaseHelper dbHelper;
    private Button btnThemDanhMucChiTieu;
    private ImageButton btnHome, btnChiTieu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_muc_chi_tieu);

        // Khởi tạo các đối tượng
        recyclerViewDanhMucCT = findViewById(R.id.recyclerViewDanhMucCT);
        btnThemDanhMucChiTieu = findViewById(R.id.btnThemDanhMucChiTieu);
        btnHome = findViewById(R.id.btnHome);
        btnChiTieu = findViewById(R.id.btnChiTieu);
        dbHelper = new DatabaseHelper(this);

        // Thiết lập RecyclerView
        recyclerViewDanhMucCT.setLayoutManager(new LinearLayoutManager(this));

        // Cài đặt nút Home và Chi Tiêu
        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(DanhMucChiTieu.this, HomeActivity.class);
            startActivity(intent);
        });

        btnChiTieu.setOnClickListener(v -> {
            Intent intent = new Intent(DanhMucChiTieu.this, ChiTieuActivity.class);
            startActivity(intent);
        });

        // Cài đặt adapter cho RecyclerView
        adapter = new DanhMucChiTieuAdapter(danhMucChiTieuList, new DanhMucChiTieuAdapter.OnItemClickListener() {
            @Override
            public void onEditClick(int position) {
                editDanhMuc(position);
            }

            @Override
            public void onDeleteClick(int position) {
                deleteDanhMuc(position);
            }
        });
        recyclerViewDanhMucCT.setAdapter(adapter);

        // Tải danh mục chi tiêu từ cơ sở dữ liệu và hiển thị
        loadDanhMucChiTieu();

        // Thêm danh mục mới khi nhấn nút Thêm Danh Mục
        btnThemDanhMucChiTieu.setOnClickListener(v -> addDanhMuc());
    }

    // Phương thức tải danh mục chi tiêu
    private void loadDanhMucChiTieu() {
        danhMucChiTieuList.clear();
        List<String> categories = dbHelper.getDanhMucChiTieuByType("chi tiêu");  // Lấy danh mục chi tiêu

        if (categories != null && !categories.isEmpty()) {
            danhMucChiTieuList.addAll(categories);
        }
        adapter.notifyDataSetChanged();
    }

    // Phương thức thêm danh mục chi tiêu mới
    private void addDanhMuc() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Thêm danh mục chi tiêu");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("Thêm", (dialog, which) -> {
            String newDanhMuc = input.getText().toString();
            if (!newDanhMuc.isEmpty()) {
                int userId = UserSession.getInstance().getUserId();  // Lấy userId từ session
                dbHelper.themDanhMucChiTieu(newDanhMuc, userId);  // Thêm danh mục chi tiêu với userId
                loadDanhMucChiTieu();  // Cập nhật lại danh sách
            }
        });
        builder.setNegativeButton("Hủy", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Phương thức chỉnh sửa danh mục chi tiêu
    private void editDanhMuc(int position) {
        String currentDanhMuc = danhMucChiTieuList.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Chỉnh sửa danh mục chi tiêu");

        final EditText input = new EditText(this);
        input.setText(currentDanhMuc);
        builder.setView(input);

        builder.setPositiveButton("Lưu", (dialog, which) -> {
            String newDanhMuc = input.getText().toString();
            if (!newDanhMuc.isEmpty()) {
                dbHelper.capNhatDanhMucChiTieu(currentDanhMuc, newDanhMuc);  // Cập nhật danh mục
                loadDanhMucChiTieu();  // Cập nhật lại danh sách sau khi chỉnh sửa
            }
        });
        builder.setNegativeButton("Hủy", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Phương thức xóa danh mục chi tiêu
    private void deleteDanhMuc(int position) {
        String danhMuc = danhMucChiTieuList.get(position);
        dbHelper.xoaDanhMucChiTieu(danhMuc);  // Xóa danh mục chi tiêu
        loadDanhMucChiTieu();  // Cập nhật lại danh sách sau khi xóa
    }
}
