package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import adapter.TransactionAdapter;

public class ChiTieuActivity extends AppCompatActivity {

    private EditText edtSoTien, edtMota;
    private Button btnChonDanhMuc, btnLuuChiTieu;
    ImageButton btnGoToHome;
    private ImageView btnChonNgay, btnChonGio;
    private TextView tvDateTime, tvTongChiTieu;
    private DatabaseHelper dbHelper;
    private int selectedCategoryId;
    private int currentUserId = 1; // ID người dùng hiện tại
    private ListView lvChiTieu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tieu);

        // Khởi tạo DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Khởi tạo các View
        initializeViews();

        // Hiển thị danh sách chi tiêu và tính tổng chi tiêu
        hienThiChiTieu();

        // Sự kiện chọn danh mục chi tiêu
        btnChonDanhMuc.setOnClickListener(v -> showCategoryDialog());

        // Sự kiện chọn ngày
        btnChonNgay.setOnClickListener(v -> showDatePickerDialog());

        // Sự kiện chọn giờ
        btnChonGio.setOnClickListener(v -> showTimePickerDialog());

        // Sự kiện lưu chi tiêu
        btnLuuChiTieu.setOnClickListener(v -> themChiTieu());

        // Sự kiện chuyển sang HomeActivity và truyền tổng chi tiêu
        btnGoToHome.setOnClickListener(v -> goToHomeActivity());
    }

    private void initializeViews() {
        edtSoTien = findViewById(R.id.edtSoTienChiTieu);
        edtMota = findViewById(R.id.edtMotaChiTieu);
        btnChonDanhMuc = findViewById(R.id.btnChonDanhMucChiTieu);
        btnChonNgay = findViewById(R.id.btnChonNgayChiTieu);
        btnChonGio = findViewById(R.id.btnChonGioChiTieu);
        tvDateTime = findViewById(R.id.tvDateTimeChiTieu);
        tvTongChiTieu = findViewById(R.id.tvTongChiTieu);
        btnLuuChiTieu = findViewById(R.id.btnLuuChiTieu);
        lvChiTieu = findViewById(R.id.lvChiTieu);
        btnGoToHome = findViewById(R.id.btnGoToHome);
    }

    private void hienThiChiTieu() {
        ArrayList<Transaction> transactions = dbHelper.layTatCaGiaoDich(currentUserId, "chi tiêu");

        if (transactions == null || transactions.isEmpty()) {
            Toast.makeText(this, "Không có chi tiêu", Toast.LENGTH_SHORT).show();
            return;
        }

        // Cập nhật tổng chi tiêu
        double totalChiTieu = calculateTotalChiTieu(transactions);

        tvTongChiTieu.setText(String.format("Tổng chi tiêu: %,d đ", (int) totalChiTieu));

        // Cập nhật ListView
        TransactionAdapter transactionAdapter = new TransactionAdapter(this, transactions);
        lvChiTieu.setAdapter(transactionAdapter);

        lvChiTieu.setOnItemLongClickListener((parent, view, position, id) -> {
            Transaction selectedTransaction = transactions.get(position);
            showDeleteTransactionDialog(selectedTransaction);
            return true;
        });
    }

    private double calculateTotalChiTieu(ArrayList<Transaction> transactions) {
        double total = 0;
        for (Transaction transaction : transactions) {
            total += transaction.getAmount();
        }
        return total;
    }

    private void showDeleteTransactionDialog(Transaction selectedTransaction) {
        new AlertDialog.Builder(ChiTieuActivity.this)
                .setTitle("Xóa giao dịch")
                .setMessage("Bạn có chắc chắn muốn xóa giao dịch này?")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    boolean isDeleted = dbHelper.xoaChiTieu(selectedTransaction.getId());
                    if (isDeleted) {
                        Toast.makeText(ChiTieuActivity.this, "Xóa giao dịch thành công", Toast.LENGTH_SHORT).show();
                        hienThiChiTieu(); // Cập nhật lại danh sách chi tiêu
                    } else {
                        Toast.makeText(ChiTieuActivity.this, "Lỗi khi xóa giao dịch", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showCategoryDialog() {
        ArrayList<String> danhMucChiTieu = (ArrayList<String>) dbHelper.layDanhMucTheoLoai("chi tiêu");

        if (danhMucChiTieu.isEmpty()) {
            Toast.makeText(this, "Không có danh mục chi tiêu", Toast.LENGTH_SHORT).show();
            return;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, danhMucChiTieu);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Chọn danh mục chi tiêu");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_listview_category, null);
        ListView listViewCategories = dialogView.findViewById(R.id.listViewCategories);
        listViewCategories.setAdapter(adapter);

        listViewCategories.setOnItemClickListener((parent, view, position, id) -> {
            String selectedCategory = danhMucChiTieu.get(position);
            selectedCategoryId = dbHelper.layCategoryIdTheoTen(selectedCategory, "chi tiêu");
            btnChonDanhMuc.setText(selectedCategory);
            builder.create().dismiss();
        });

        builder.setView(dialogView);
        builder.setCancelable(true);
        builder.create().show();
    }

    private void themChiTieu() {
        try {
            double soTien = Double.parseDouble(edtSoTien.getText().toString().replace(".", ""));
            String ngayThang = tvDateTime.getText().toString();
            String moTa = edtMota.getText().toString();

            if (ngayThang.equals("Ngày và giờ sẽ được hiển thị ở đây")) {
                Toast.makeText(this, "Vui lòng chọn ngày và giờ", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isSuccess = dbHelper.themChiTieu(soTien, ngayThang, moTa, selectedCategoryId, currentUserId);

            if (isSuccess) {
                Toast.makeText(this, "Thêm chi tiêu thành công", Toast.LENGTH_SHORT).show();
                hienThiChiTieu();  // Cập nhật lại danh sách chi tiêu
            } else {
                Toast.makeText(this, "Thêm chi tiêu thất bại", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Số tiền không hợp lệ", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, monthOfYear, dayOfMonth) -> {
                    String date = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                    tvDateTime.setText(date);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view, hourOfDay, minute) -> {
                    String time = hourOfDay + ":" + (minute < 10 ? "0" + minute : minute);
                    tvDateTime.append(" " + time);
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
        );
        timePickerDialog.show();
    }

    private void goToHomeActivity() {
        ArrayList<Transaction> transactions = dbHelper.layTatCaGiaoDich(currentUserId, "chi tiêu");
        double totalChiTieu = calculateTotalChiTieu(transactions);

        Intent intent = new Intent(ChiTieuActivity.this, HomeActivity.class);
        intent.putExtra("tongChiTieu", totalChiTieu);
        startActivity(intent);
        finish();
    }
}
