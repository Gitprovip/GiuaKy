package vn.edu.stu.doanquanlychitieu_nguyenhuutruong;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import adapter.DanhMucThuNhapAdapter;

public class DanhMucThuNhap extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DanhMucThuNhapAdapter adapter;
    private List<String> danhMucList = new ArrayList<>();
    private DatabaseHelper dbHelper;
    private Button btnThemDanhMuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_muc_thu_nhap);

        recyclerView = findViewById(R.id.recyclerViewDanhMuc);
        btnThemDanhMuc = findViewById(R.id.btnThemDanhMuc);
        dbHelper = new DatabaseHelper(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ImageButton btnHome = findViewById(R.id.btnHome);
        ImageButton btnThuNhap = findViewById(R.id.btnThuNhap);

        // Chuyển đến HomeActivity khi nhấn nút Home
        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(DanhMucThuNhap.this, HomeActivity.class);
            startActivity(intent);
        });

        // Chuyển đến ThuNhapActivity khi nhấn nút Thu Nhập
        btnThuNhap.setOnClickListener(v -> {
            Intent intent = new Intent(DanhMucThuNhap.this, ThuNhapActivity.class);
            startActivity(intent);
        });

        // Set up adapter cho RecyclerView
        adapter = new DanhMucThuNhapAdapter(danhMucList, new DanhMucThuNhapAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(String danhMuc) {
                // Xử lý khi người dùng click vào một danh mục thu nhập
            }

            @Override
            public void onEditClick(int position) {
                // Lấy danh mục cần chỉnh sửa
                String oldDanhMuc = danhMucList.get(position);

                // Tạo hộp thoại để chỉnh sửa tên danh mục thu nhập
                AlertDialog.Builder builder = new AlertDialog.Builder(DanhMucThuNhap.this);
                builder.setTitle("Chỉnh sửa danh mục thu nhập");

                final EditText input = new EditText(DanhMucThuNhap.this);
                input.setText(oldDanhMuc);  // Hiển thị tên danh mục cũ vào EditText
                builder.setView(input);

                builder.setPositiveButton("Lưu", (dialog, which) -> {
                    String newDanhMuc = input.getText().toString();
                    if (!newDanhMuc.isEmpty() && !newDanhMuc.equals(oldDanhMuc)) {
                        // Cập nhật danh mục thu nhập trong cơ sở dữ liệu
                        dbHelper.capNhatDanhMucThuNhap(oldDanhMuc, newDanhMuc);
                        loadDanhMucThuNhap();  // Cập nhật lại danh sách sau khi sửa
                    }
                });

                builder.setNegativeButton("Hủy", (dialog, which) -> dialog.cancel());
                builder.show();
            }

            @Override
            public void onDeleteClick(int position) {
                // Xử lý khi người dùng muốn xóa một danh mục thu nhập
                AlertDialog.Builder builder = new AlertDialog.Builder(DanhMucThuNhap.this);
                builder.setMessage("Bạn có muốn xóa danh mục này?")
                        .setPositiveButton("Yes", (dialog, id) -> {
                            // Lấy danh mục cần xóa
                            String danhMucToDelete = danhMucList.get(position);
                            dbHelper.xoaDanhMucThuNhap(danhMucToDelete); // Giả sử bạn đã tạo phương thức xóa trong DatabaseHelper
                            loadDanhMucThuNhap(); // Cập nhật lại danh sách sau khi xóa
                        })
                        .setNegativeButton("No", (dialog, id) -> dialog.cancel())
                        .create()
                        .show();
            }
        });

        recyclerView.setAdapter(adapter);

        // Lấy danh mục thu nhập từ cơ sở dữ liệu và hiển thị
        loadDanhMucThuNhap();

        // Thêm danh mục mới khi nhấn nút Thêm Danh Mục
        btnThemDanhMuc.setOnClickListener(v -> addDanhMuc());
    }

    private void loadDanhMucThuNhap() {
        // Lấy danh mục thu nhập từ cơ sở dữ liệu và cập nhật danh sách
        danhMucList.clear();
        List<String> categories = dbHelper.getDanhMucThuNhapByType("thu nhập");  // Chỉ lấy danh mục thu nhập

        // Kiểm tra danh sách danh mục thu nhập
        Log.d("DanhMucThuNhap", "Danh mục thu nhập: " + categories.toString());

        if (categories != null && !categories.isEmpty()) {
            danhMucList.addAll(categories);
        }
        adapter.notifyDataSetChanged();
    }

    private void addDanhMuc() {
        // Tạo hộp thoại nhập tên danh mục thu nhập mới
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Thêm danh mục thu nhập");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("Thêm", (dialog, which) -> {
            String newDanhMuc = input.getText().toString();
            if (!newDanhMuc.isEmpty()) {
                // Thêm danh mục thu nhập vào cơ sở dữ liệu
                int userId = UserSession.getInstance().getUserId();  // Lấy userId từ session
                dbHelper.themDanhMucThuNhap(newDanhMuc, userId);  // Thêm danh mục thu nhập với userId
                loadDanhMucThuNhap();  // Cập nhật lại danh sách
            }
        });
        builder.setNegativeButton("Hủy", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}
